<?php
$url = $_SERVER['REQUEST_URI'];

if(strpos($url, '/api/verification') !== false){
    $data = ['result'=>true, 'msg'=>'ok'];
    echo serialize($data);
}
elseif(strpos($url, '/api/update') !== false){
    $version = $_POST['version'];
    $data = ['result'=>null, 'msg'=>'暂无更新，您当前的版本[V'.$version.']已是最新版','version'=>$version];
    echo serialize($data);
}
