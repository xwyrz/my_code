<?php
/*
 * @Author        : Qinver
 * @Url           : zibll.com
 * @Date          : 2020-09-29 13:18:36
 * @LastEditTime: 2021-12-16 21:08:34
 * @Email         : 770349780@qq.com
 * @Project       : Zibll子比主题
 * @Description   : 一款极其优雅的Wordpress主题
 * @Read me       : 感谢您使用子比主题，主题源码有详细的注释，支持二次开发。
 * @Remind        : 使用盗版主题会存在各种未知风险。支持正版，从我做起！
 */

function zib_ajax_new_posts()
{

    $cuid = get_current_user_id();

    if (!_pz('post_article_s')) {
        echo (json_encode(array('error' => 1, 'ys' => 'danger', 'msg' => '投稿功能已关闭')));
        exit();
    }

    //权限判断
    if (!zib_current_user_can('new_post_add')) {
        zib_send_json_error('抱歉您的权限不足，暂时无法发布');
    }

    $title    = !empty($_POST['post_title']) ? $_POST['post_title'] : false;
    $content  = !empty($_POST['post_content']) ? $_POST['post_content'] : false;
    $cat      = !empty($_POST['category']) ? $_POST['category'] : false;
    $action   = !empty($_POST['action']) ? $_POST['action'] : false;
    $draft_id = '';
    if ($cuid) {
        $draft_id = get_user_meta($cuid, 'posts_draft', true);
    }

    $posts_id = !empty($_POST['posts_id']) ? $_POST['posts_id'] : ($draft_id ? $draft_id : 0);

    if (empty($title)) {
        echo (json_encode(array('error' => 1, 'ys' => 'warning', 'msg' => '请填写文章标题')));
        exit();
    }
    if (empty($content)) {
        echo (json_encode(array('error' => 1, 'ys' => 'warning', 'msg' => '还未填写任何内容')));
        exit();
    }

    if ('posts_save' == $action) {
        if (_new_strlen($title) > 30) {
            echo (json_encode(array('error' => 1, 'ys' => 'danger', 'msg' => '标题太长了，不能超过30个字')));
            exit();
        }
        if (_new_strlen($title) < 5) {
            echo (json_encode(array('error' => 1, 'ys' => 'danger', 'msg' => '标题太短！')));
            exit();
        }
        if (_new_strlen($content) < 10) {
            echo (json_encode(array('error' => 1, 'ys' => 'danger', 'msg' => '文章内容过少')));
            exit();
        }
        if (empty($cat)) {
            echo (json_encode(array('error' => 1, 'ys' => 'warning', 'msg' => '请选择文章分类')));
            exit();
        }
    }
    $post_author = $cuid;

    //内容合规性判断
    $is_audit = false;
    if (zib_current_user_can('new_post_audit_no')) {
        //拥有免审核权限
        $is_audit = true;
    } else {
        //API审核（拥有免审核权限的用户无需API审核）
        if (_pz('audit_new_post')) {
            $api_is_audit = ZibAudit::is_audit(ZibAudit::ajax_text($title . $content));
            //API审核通过，且拥有免人工审核
            if ($api_is_audit && zib_current_user_can('new_post_audit_no_manual')) {
                $is_audit = true;
            }
        }
    }

    if (!$cuid) {
        if (empty($_POST['user_name'])) {
            echo (json_encode(array('error' => 1, 'msg' => '请输入昵称')));
            exit();
        }
        $post_author = _pz('post_article_user', 1);
        $lx          = !empty($_POST['contact_details']) ? ',联系：' . esc_attr($_POST['contact_details']) : '';
        $title       = $title . '[投稿-姓名：' . esc_attr($_POST['user_name']) . $lx . ']';
    }

    $cat   = array();
    $cat[] = !empty($_POST['category']) ? $_POST['category'] : false;
    $tags  = preg_split("/,|，|\s|\n/", $_POST['tags']);

    $postarr = array(
        'post_title'     => $title,
        'post_status'    => 'draft',
        'ID'             => $posts_id,
        'post_content'   => $content,
        'post_category'  => $cat,
        'tags_input'     => $tags,
        'comment_status' => 'open',
    );

    if (!$posts_id) {
        //新建时候，添加作者
        $postarr['post_author'] = $post_author;
    } else {
        $post_obj = get_post($posts_id, ARRAY_A);
        if (isset($post_obj['ID'])) {
            $postarr = array_merge($post_obj, $postarr);
        }
    }

    if ('posts_save' === $action) {
        $postarr['post_status'] = 'pending'; //默认为待审核状态 发布无需审核
        //通过了API审核或者自己拥有无需审核权限
        if ($is_audit) {
            $postarr['post_status'] = 'publish';
        }
    }

    //保存文章
    $in_id = wp_insert_post($postarr, 1);

    if (is_wp_error($in_id)) {
        echo (json_encode(array('error' => 1, 'ys' => 'danger', 'msg' => $in_id->get_error_message())));
        exit();
    }
    if (!$in_id) {
        echo (json_encode(array('error' => 1, 'ys' => 'danger', 'msg' => '投稿失败，请稍后再试')));
        exit();
    }

    $url = '';
    if ($cuid && current_user_can('edit_post', $in_id)) {
        $url = get_permalink($in_id);
    }
    $send             = array();
    $send['posts_id'] = $in_id;
    $send['url']      = $url;

    switch ($postarr['post_status']) {
        case 'pending': //待审核
            //添加挂钩
            do_action('new_posts_pending', get_post($in_id));

            $send['msg'] = '内容已提交，正在等待审核';
            if ($cuid) {
                $send['reload'] = true;
                $send['goto']   = zib_get_user_home_url($post_author, array('post_status' => 'pending'));
            }

            break;
        case 'draft': //草稿
            update_user_meta($cuid, 'posts_draft', $in_id);
            $send['msg']       = '草稿已保存';
            $send['time']      = current_time('mysql');
            $send['posts_url'] = $url;

            break;
        default:
            $send['msg']    = '文章已发布';
            $send['reload'] = true;
            $send['goto']   = $url;
    }
    zib_send_json_success($send);

}
add_action('wp_ajax_posts_save', 'zib_ajax_new_posts');
add_action('wp_ajax_nopriv_posts_save', 'zib_ajax_new_posts');
add_action('wp_ajax_posts_draft', 'zib_ajax_new_posts');
add_action('wp_ajax_nopriv_posts_draft', 'zib_ajax_new_posts');
