<?php
/*
 * @Author        : Qinver
 * @Url           : zibll.com
 * @Date          : 2021-11-09 13:59:52
 * @LastEditTime: 2022-02-28 21:54:32
 * @Email         : 770349780@qq.com
 * @Project       : Zibll子比主题
 * @Description   : 一款极其优雅的Wordpress主题|论坛系统|AJAX执行类函数
 * @Read me       : 感谢您使用子比主题，主题源码有详细的注释，支持二次开发。
 * @Remind        : 使用盗版主题会存在各种未知风险。支持正版，从我做起！
 */

//执行文章设置为精华，设置为置顶
function zib_bbs_ajax_posts_meta_save()
{
    $post_id = isset($_REQUEST['id']) ? (int) $_REQUEST['id'] : 0;
    $action  = isset($_REQUEST['action']) ? $_REQUEST['action'] : 0;

    //执行安全验证检查，验证不通过自动结束并返回提醒
    zib_ajax_verify_nonce();

    $get_post = get_post($post_id);
    if (!$post_id || empty($get_post->ID)) {
        echo json_encode((array('error' => 1, 'ys' => 'danger', 'msg' => '参数传入错误')));
        exit;
    }

    //权限检查
    if (!zib_bbs_current_user_can($action, $post_id)) {
        echo json_encode((array('error' => 1, 'ys' => 'danger', 'msg' => '暂无此权限')));
        exit;
    }

    $reload = true;
    switch ($action) {
        case 'posts_essence_set':
            $cancel = !empty($_REQUEST['cancel']) ? $_REQUEST['cancel'] : false;

            $val = $cancel ? '' : '1';
            update_post_meta($post_id, 'essence', $val);
            do_action('bbs_posts_essence_set', $post_id, $val); //添加挂钩

            $msg    = $cancel ? '已取消此内容的精华称号' : '已将此内容设置为精华';
            $reload = true;

            break;

        case 'posts_topping_set':
            $topping = !empty($_REQUEST['topping']) ? $_REQUEST['topping'] : 0;

            update_post_meta($post_id, 'topping', $topping);
            do_action('bbs_posts_topping_set', $post_id, $topping); //添加挂钩

            if ('0' == $topping) {
                $msg = '已取消置顶';
            } else {
                $name = zib_bbs_get_posts_topping_options();
                $name = isset($name[$topping]) ? $name[$topping] : '置顶';
                $msg  = '已' . $name . '此内容';
            }

            break;
    }

    echo (json_encode(array('error' => 0, 'ys' => '', 'reload' => $reload, 'msg' => $msg)));
    exit;
}
add_action('wp_ajax_posts_essence_set', 'zib_bbs_ajax_posts_meta_save');
add_action('wp_ajax_posts_topping_set', 'zib_bbs_ajax_posts_meta_save');

//帖子设置置顶的模态框
function zib_bbs_ajax_posts_topping_set_modal()
{
    $action = isset($_REQUEST['action']) ? $_REQUEST['action'] : 0;
    $id     = isset($_REQUEST['id']) ? (int) $_REQUEST['id'] : 0;

    $post = get_post($id);
    if (empty($post->ID)) {
        zib_ajax_notice_modal('danger', '内容不存在或参数传入错误');
    }
    if (!zib_bbs_current_user_can('posts_topping_set', $post->ID)) {
        zib_ajax_notice_modal('danger', '您没有该操作权限');
    }

    $html = zib_bbs_edit::topping($id);

    echo $html;
    exit;
}
add_action('wp_ajax_posts_topping_set_modal', 'zib_bbs_ajax_posts_topping_set_modal');

//帖子设置阅读权限的模态框
function zib_bbs_ajax_posts_allow_view_set_modal()
{
    $action = isset($_REQUEST['action']) ? $_REQUEST['action'] : 0;
    $id     = isset($_REQUEST['id']) ? (int) $_REQUEST['id'] : 0;

    $post = get_post($id);
    if (empty($post->ID)) {
        zib_ajax_notice_modal('danger', '内容不存在或参数传入错误');
    }
    if (!zib_bbs_current_user_can('posts_allow_view_edit', $id)) {
        zib_ajax_notice_modal('danger', '权限不足');
    }
    $allow_view_set = zib_bbs_edit::allow_view_set_content($id);
    $header         = zib_get_modal_colorful_header('jb-yellow', '<i class="fa fa-unlock-alt"></i>', '设置阅读权限');
    $hidden_html    = '';
    $hidden_html .= '<input type="hidden" name="action" value="edit_allow_view">';
    $hidden_html .= '<input type="hidden" name="post_id" value="' . $id . '">';

    $footer = '<div class="mt20 but-average">';
    $footer .= $hidden_html;
    $footer .= '<button class="but jb-yellow padding-lg wp-ajax-submit"><i class="fa fa-check" aria-hidden="true"></i>确认提交</button>';
    $footer .= '</div>';

    echo '<form class="dependency-box">';
    echo $header;
    echo '<div class="mini-scrollbar scroll-y max-vh5">' . $allow_view_set . '</div>';
    echo $footer;
    echo '</form>';
    exit;
}
add_action('wp_ajax_posts_allow_view_set_modal', 'zib_bbs_ajax_posts_allow_view_set_modal');

//执行帖子移动板块
function zib_bbs_ajax_posts_plate_move()
{
    $id       = isset($_REQUEST['id']) ? (int) $_REQUEST['id'] : 0;
    $plate_id = isset($_REQUEST['plate']) ? (int) $_REQUEST['plate'] : 0;
    global $zib_bbs;
    $plate_name = $zib_bbs->plate_name;

    if (!$plate_id) {
        echo json_encode((array('error' => 1, 'ys' => 'danger', 'msg' => '请选择' . $plate_name)));
        exit;
    }

    //执行安全验证检查，验证不通过自动结束并返回提醒
    zib_ajax_verify_nonce('save_bbs');

    $post = get_post($id);
    if (empty($post->ID)) {
        echo json_encode((array('error' => 1, 'ys' => 'danger', 'msg' => '内容不存在或参数传入错误')));
        exit;
    }
    //权限验证
    if (!zib_bbs_current_user_can('posts_plate_move', $post)) {
        echo json_encode((array('error' => 1, 'ys' => 'danger', 'msg' => '您没有该操作权限')));
        exit;
    }

    //新板块选择权限验证
    if (!zib_bbs_current_user_can('select_plate', $plate_id, $post)) {
        zib_send_json_error('抱歉！您暂无选择此' . $plate_name . '的权限，请重新选择' . $plate_name);
    }

    $old_id = zib_bbs_get_plate_id($id);
    if ($old_id == $plate_id) {
        echo json_encode((array('error' => 1, 'ys' => 'danger', 'msg' => '所选' . $plate_name . '未做任何修改')));
        exit;
    }

    //执行移动板块
    zib_bbs_posts_plate_move($id, $plate_id, $old_id);

    echo (json_encode(array('error' => 0, 'ys' => '', 'reload' => true, 'msg' => '切换成功')));
    exit;
}
add_action('wp_ajax_plate_move', 'zib_bbs_ajax_posts_plate_move');

//帖子移动板块的模态框
function zib_bbs_ajax_posts_plate_move_modal()
{
    $action = isset($_REQUEST['action']) ? $_REQUEST['action'] : 0;
    $id     = isset($_REQUEST['id']) ? (int) $_REQUEST['id'] : 0;

    $post = get_post($id);
    if (empty($post->ID)) {
        zib_ajax_notice_modal('danger', '内容不存在或参数传入错误');
    }
    if (!zib_bbs_current_user_can('posts_plate_move', $post)) {
        echo zib_get_null('抱歉！暂无此权限', 30, 'null-cap.svg', '', 200, 150);
        exit;
    }

    $html = zib_bbs_edit::plate_move($id);

    echo $html;
    exit;
}
add_action('wp_ajax_posts_plate_move_modal', 'zib_bbs_ajax_posts_plate_move_modal');

//删除内容的弹窗
function zib_bbs_ajax_delete_modal()
{
    $action = isset($_REQUEST['action']) ? $_REQUEST['action'] : 0;
    $id     = isset($_REQUEST['id']) ? (int) $_REQUEST['id'] : 0;

    if (!$id) {
        zib_ajax_notice_modal('danger', '参数传入错误');
    }

    switch ($action) {

        case 'posts_delete_modal':

            $post = get_post($id);
            if (empty($post->ID)) {
                zib_ajax_notice_modal('danger', '内容不存在或参数传入错误');
            }
            if (!zib_bbs_current_user_can('posts_delete', $post)) {
                zib_ajax_notice_modal('danger', '您没有删除此内容的权限');
            }
            if ('forum_post' != $post->post_type) {
                zib_ajax_notice_modal('danger', '类型错误或参数传入错误');
            }

            $html = zib_bbs_edit::posts_delete($post);
            break;

        case 'plate_delete_modal':

            $post = get_post($id);
            if (empty($post->ID)) {
                zib_ajax_notice_modal('danger', '内容不存在或参数传入错误');
            }
            if (!zib_bbs_current_user_can('plate_delete', $post)) {
                zib_ajax_notice_modal('danger', '您没有删除此内容的权限');
            }
            if ('plate' != $post->post_type) {
                zib_ajax_notice_modal('danger', '类型错误或参数传入错误');
            }

            $html = zib_bbs_edit::plate_delete($post);
            break;

        case 'posts_audit_modal':
        case 'plate_audit_modal':

            $post = get_post($id);

            if (empty($post->ID)) {
                zib_ajax_notice_modal('danger', '内容不存在或参数传入错误');
            }
            if ('forum_post' === $post->post_type && !zib_bbs_current_user_can('posts_audit', $post)) {
                zib_ajax_notice_modal('danger', '您没有审核的权限');
            }
            if ('plate' === $post->post_type && !zib_bbs_current_user_can('plate_audit', $post)) {
                zib_ajax_notice_modal('danger', '您没有审核的权限');
            }

            $html = zib_bbs_edit::audit($post);
            break;

        case 'plate_cat_delete_modal':
        case 'forum_topic_delete_modal':
        case 'forum_tag_delete_modal':
            $term = get_term($id);

            if (empty($term->term_id)) {
                zib_ajax_notice_modal('danger', '内容不存在或参数传入错误');
            }

            $taxonomy = $term->taxonomy;
            if (!zib_bbs_current_user_can($taxonomy . '_delete', $term->term_id)) {
                zib_ajax_notice_modal('danger', '您没有删除此内容的权限');
            }

            $html = zib_bbs_edit::term_delete($term);
            break;
    }

    echo $html;
    exit;
}
add_action('wp_ajax_posts_delete_modal', 'zib_bbs_ajax_delete_modal');
add_action('wp_ajax_plate_delete_modal', 'zib_bbs_ajax_delete_modal');
add_action('wp_ajax_posts_audit_modal', 'zib_bbs_ajax_delete_modal');
add_action('wp_ajax_plate_audit_modal', 'zib_bbs_ajax_delete_modal');
add_action('wp_ajax_plate_cat_delete_modal', 'zib_bbs_ajax_delete_modal');
add_action('wp_ajax_forum_topic_delete_modal', 'zib_bbs_ajax_delete_modal');
add_action('wp_ajax_forum_tag_delete_modal', 'zib_bbs_ajax_delete_modal');

//执行删除板块或者文章的审核
function zib_bbs_ajax_plate_or_posts_audit()
{
    $id = isset($_REQUEST['id']) ? (int) $_REQUEST['id'] : 0;

    $post = get_post($id);

    //执行安全验证检查，验证不通过自动结束并返回提醒
    zib_ajax_verify_nonce();

    global $zib_bbs;

    if (empty($post->ID)) {
        zib_send_json_error('内容不存在或参数传入错误');
    }
    //权限判断
    if ('forum_post' === $post->post_type && !zib_bbs_current_user_can('posts_audit', $post)) {
        zib_send_json_error('您没有审核' . $zib_bbs->posts_name . '的权限');
    }
    if ('plate' === $post->post_type && !zib_bbs_current_user_can('plate_audit', $post)) {
        zib_send_json_error('您没有审核' . $zib_bbs->plate_name . '的权限');
    }

    if ('pending' === $post->post_status) {
        $post_status = 'publish';
        $mag         = '内容已审核发布';
    } else {
        $post_status = 'pending';
        $mag         = '内容已驳回审核';
    }

    $post_updated = wp_update_post(
        array(
            'ID'          => $post->ID,
            'post_status' => $post_status,
        )
    );

    if (!$post_updated) {
        zib_send_json_error('操作失败，请刷新页面重试');
    }

    $goto = '';
    zib_send_json_success(array('msg' => $mag, 'reload' => true, 'goto' => $goto));
}
add_action('wp_ajax_plate_audit', 'zib_bbs_ajax_plate_or_posts_audit');
add_action('wp_ajax_posts_audit', 'zib_bbs_ajax_plate_or_posts_audit');

//执行删除板块或者文章的撤销
function zib_bbs_ajax_plate_or_posts_delete_revoke()
{
    $plate_id = isset($_REQUEST['id']) ? (int) $_REQUEST['id'] : 0;
    $action   = isset($_REQUEST['action']) ? $_REQUEST['action'] : 0;

    $plate = get_post($plate_id);

    if (!$plate_id || !$plate) {
        echo json_encode((array('error' => 1, 'ys' => 'danger', 'msg' => '参数传入错误')));
        exit;
    }
    //执行安全验证检查，验证不通过自动结束并返回提醒
    zib_ajax_verify_nonce();

    global $zib_bbs;

    if ('plate_delete_revoke' === $action) {
        $name = $zib_bbs->plate_name;
        if (!zib_bbs_current_user_can('plate_edit', $plate)) {
            echo json_encode((array('error' => 1, 'ys' => 'danger', 'msg' => '您没有恢复此' . $name . '的权限')));
            exit;
        }
    } else {
        $name = $zib_bbs->posts_name;
        if (!zib_bbs_current_user_can('posts_edit', $plate)) {
            echo json_encode((array('error' => 1, 'ys' => 'danger', 'msg' => '您没有恢复此' . $name . '的权限')));
            exit;
        }
    }

    //执行删除文章
    wp_untrash_post($plate_id);

    $goto = get_permalink($plate_id);

    echo (json_encode(array('error' => 0, 'ys' => '', 'reload' => true, 'goto' => $goto, 'msg' => '该' . $name . '已移出回收站')));
    exit;
}
add_action('wp_ajax_plate_delete_revoke', 'zib_bbs_ajax_plate_or_posts_delete_revoke');
add_action('wp_ajax_posts_delete_revoke', 'zib_bbs_ajax_plate_or_posts_delete_revoke');

//帖子页的评分用户明细
function zib_bbs_ajax_score_user_lists()
{

    $id    = !empty($_REQUEST['id']) ? $_REQUEST['id'] : '';
    $paged = !empty($_REQUEST['paged']) ? $_REQUEST['paged'] : 1;

    $html = zib_bbs_get_score_user_lists($id, '', $paged);
    echo $html;
    exit;
}
add_action('wp_ajax_score_user_lists', 'zib_bbs_ajax_score_user_lists');
add_action('wp_ajax_nopriv_score_user_lists', 'zib_bbs_ajax_score_user_lists');

//保存帖子
function zib_bbs_ajax_edit_posts()
{
    global $zib_bbs;
    $cuid         = get_current_user_id();
    $action       = !empty($_REQUEST['action']) ? $_REQUEST['action'] : 'bbs_posts_save';
    $post_id      = !empty($_REQUEST['post_id']) ? (int) $_REQUEST['post_id'] : 0;
    $is_new       = !$post_id;
    $post_content = !empty($_REQUEST['post_content']) ? $_REQUEST['post_content'] : '';
    $post_title   = !empty($_REQUEST['post_title']) ? strip_tags(trim($_REQUEST['post_title'])) : '';
    $plate        = !empty($_REQUEST['plate']) ? (int) $_REQUEST['plate'] : 0;
    $tag_g        = !empty($_REQUEST['tag']) ? $_REQUEST['tag'] : 0;
    $topic        = !empty($_REQUEST['topic']) ? (int) $_REQUEST['topic'] : 0;
    $post_status  = 'draft'; //默认为草稿
    $tag          = false;
    if (is_array($tag_g)) {
        foreach ($tag_g as $t) {
            $tag[] = (int) $t;
        }
    }

    //执行安全验证检查，验证不通过自动结束并返回提醒
    zib_ajax_verify_nonce('bbs_edit_posts');

    //权限验证
    if ($is_new) {
        if (!zib_bbs_current_user_can('posts_add')) {
            zib_send_json_error('暂无发布权限');
        }

    } else {
        if (!zib_bbs_current_user_can('posts_edit', $post_id)) {
            zib_send_json_error('您没有编辑此内容的权限');
        }
    }

    //板块选择验证
    if (!zib_bbs_current_user_can('select_plate', $plate, $post_id)) {
        zib_send_json_error('您暂无在此' . $zib_bbs->plate_name . '发布的权限，请重新选择' . $zib_bbs->plate_name);
    }

    //内容长度验证
    if (!$post_title) {
        zib_send_json_error('请填写标题');
    }
    if (!$post_content) {
        zib_send_json_error('还未填写任何内容');
    }
    if (_new_strlen($post_title) > 30) {
        zib_send_json_error('标题太长了，不能超过30个字');
    }

    if ('bbs_posts_save' == $action) {
        //提交保存、审核、发布
        if (_new_strlen($post_title) < 5) {
            zib_send_json_error('标题太短！');
        }
        if (_new_strlen($post_content) < 10) {
            zib_send_json_error('内容过少');
        }

        if (!$plate) {
            zib_send_json_error('请选择' . $zib_bbs->plate_name);
        }
    }

    //内容合规性判断
    $is_audit = false;
    if (zib_bbs_current_user_can('posts_save_audit_no') || ($post_id && zib_bbs_current_user_can('posts_audit', $post_id)) || ($plate && zib_bbs_current_user_can('posts_audit', $plate))) {
        //拥有免审核权限，或者拥有人工审核此帖子的权限
        $is_audit = true;
    } else {
        //API审核（拥有免审核权限的用户无需API审核）
        if (_pz('audit_bbs_posts')) {
            $api_is_audit = ZibAudit::is_audit(ZibAudit::ajax_text($post_title . $post_content));
            //API审核通过，且拥有免人工审核
            if ($api_is_audit && zib_bbs_current_user_can('posts_save_audit_no_manual')) {
                $is_audit = true;
            }
        }
    }

    //发布状态判断
    if ('bbs_posts_save' === $action) {
        //如果是发布
        $post_status = 'pending'; //默认为待审核状态

        if ($is_audit) {
            //判断是否拥有无需审核、无需人工审核的权限
            $post_status = !empty($_REQUEST['post_status']) ? $_REQUEST['post_status'] : 'publish';
        }
    }

    $insert_args = array(
        'ID'             => $post_id,
        'post_type'      => 'forum_post',
        'post_title'     => $post_title,
        'post_status'    => $post_status,
        'post_content'   => $post_content,
        'comment_status' => 'open',
        'meta_input'     => array(
            'plate_id' => $plate,
        ),
    );

    if (!$post_id) {
        //新建时候，添加作者
        $post_author                = !empty($_REQUEST['post_author']) ? (int) $_REQUEST['post_author'] : $cuid;
        $insert_args['post_author'] = $post_author;
    } else {
        $post_obj = get_post($post_id, ARRAY_A);
        if (isset($post_obj['ID'])) {
            $insert_args = array_merge($post_obj, $insert_args);
        }
    }

    //执行保存内容
    $insert_id = wp_insert_post($insert_args, true);

    if (is_wp_error($insert_id)) {
        //保存错误
        zib_send_json_error($insert_id->get_error_message());
    }

    //执行保存话题
    wp_set_post_terms($insert_id, array($topic), 'forum_topic');

    //执行保存标签
    wp_set_post_terms($insert_id, (array) $tag, 'forum_tag');

    //执行保存发布类型
    zib_bbs_ajax_edit_posts_bbs_type($insert_id, 0);

    //执行保存投票
    zib_bbs_ajax_edit_posts_vote($insert_id, 0);

    //执行保存阅读权限
    zib_bbs_ajax_edit_allow_view($insert_id, 0);

    $new_post_obj = get_post($insert_id);
    $permalink    = get_permalink($insert_id);
    $send         = array(
        'post_id' => $insert_id,
        'goto'    => $permalink,
        'post'    => $new_post_obj,
    );

    //添加挂钩
    do_action('bbs_' . ($is_new ? 'add' : 'edit') . '_posts', get_post($new_post_obj));

    switch ($post_status) {
        case 'pending': //待审核
            $send['reload'] = true;
            if ($cuid === $insert_args['post_author']) {
                $send['msg']  = '内容已提交，正在等待审核';
                $send['goto'] = zib_get_user_home_url($insert_args['post_author'], array('tab' => 'forum', 'status' => 'pending')); //?tab=forum&status=pending
            } else {
                $send['msg']  = '内容已修改，状态为待审核';
                $send['goto'] = get_permalink($plate);
            }
            break;
        case 'draft': //草稿
            if ($cuid === $insert_args['post_author']) {
                $send['msg']  = '草稿已保存';
                $send['html'] = '<div class="muted-2-color flex ac mb6">草稿已保存 <a class="but ml10 p2-10 px12" href="' . zib_get_user_home_url($insert_args['post_author'], array('tab' => 'forum', 'status' => 'draft')) . '">我的草稿</a></div><div class="muted-3-color em09">最后更新：' . get_the_modified_time('Y-m-d H:i:s', $insert_id) . '</div>';
            } else {
                $send['msg']  = '内容已修改，保存为草稿';
                $send['html'] = '<div class="muted-2-color flex ac mb6">草稿已保存</div><div class="muted-3-color em09">最后更新：' . get_the_modified_time('Y-m-d H:i:s', $insert_id) . '</div>';
            }

            break;
        default:
            $send['msg']    = $zib_bbs->posts_name . '已发布';
            $send['reload'] = true;
    }
    zib_send_json_success($send);
}
add_action('wp_ajax_bbs_posts_draft', 'zib_bbs_ajax_edit_posts');
add_action('wp_ajax_bbs_posts_save', 'zib_bbs_ajax_edit_posts');

//有新的用户发帖，给管理员发消息
function zib_bbs_add_posts_pending_msg($post)
{
    $user_id = $post->post_author;
    $udata   = get_userdata($user_id);

    /**判断通知状态 */
    if ($post->post_status !== 'pending' || get_post_meta($post->ID, 'add_posts_pending_msg')) {
        return;
    }

    global $zib_bbs;
    $posts_name = $zib_bbs->posts_name;
    $plate_name = $zib_bbs->plate_name;
    $plate      = get_post(zib_bbs_get_plate_id($post->ID));
    $plate_url  = get_permalink($plate);
    $title      = '有新的' . $posts_name . '待审核：' . zib_str_cut(trim(strip_tags($post->post_title)), 0, 20);
    $send_user  = 'admin';

    $message = '有新的' . $posts_name . '待审核<br />';
    $message .= '标题：' . trim(strip_tags($post->post_title)) . '<br />';
    $message .= '内容摘要：<br />';
    $message .= '<div class="muted-box" style="padding: 10px 15px; border-radius: 8px; background: rgba(125, 125, 125, 0.06); line-height: 1.7;">' . zib_str_cut(trim(strip_tags($post->post_content)), 0, 200, '...') . '</div>';
    $message .= '用户：' . zib_get_user_name_link($user_id) . '<br />';
    $message .= $plate_name . '：<a href="' . $plate_url . '">' . esc_attr($plate->post_title) . '</a><br />';
    $message .= '提交时间：' . get_the_time('Y-m-d H:i:s', $post) . '<br />';

    $message .= '<br />';
    $message .= '您可以<a href="' . $plate_url . '">点击此处</a>进入板块页面的待审核栏目，审核此内容<br />';

    /**发送邮件 */
    update_post_meta($post->ID, 'add_posts_pending_msg', true);

    $msg_arge = array(
        'send_user'    => $send_user,
        'receive_user' => 'admin',
        'type'         => 'posts',
        'title'        => $title,
        'content'      => $message,
    );

    //创建新消息
    ZibMsg::add($msg_arge);
    if (_pz('email_bbs_posts_pending_to_admin', true)) {
        $blog_name = get_bloginfo('name');
        $title     = '[' . $blog_name . '] ' . $title;
        @wp_mail(get_option('admin_email'), $title, $message);
    }
}
add_action('bbs_add_posts', 'zib_bbs_add_posts_pending_msg');

//编辑帖子保存发布类型
function zib_bbs_ajax_edit_posts_bbs_type($post_id = 0, $echo_success = true)
{
    if (!isset($_REQUEST['bbs_type'])) {
        return;
    }
    $post_id  = $post_id ? $post_id : (!empty($_REQUEST['post_id']) ? $_REQUEST['post_id'] : 0);
    $bbs_type = $_REQUEST['bbs_type'];

    //保存
    update_post_meta($post_id, 'bbs_type', $bbs_type);
}

//编辑保存帖子的投票
function zib_bbs_ajax_edit_posts_vote($post_id = 0, $echo_success = true)
{
    if (!isset($_REQUEST['vote_s']) && !isset($_REQUEST['vote'])) {
        return;
    }

    $post_id       = $post_id ? $post_id : (!empty($_REQUEST['post_id']) ? $_REQUEST['post_id'] : 0);
    $s             = !empty($_REQUEST['vote_s']) ? true : false;
    $opt           = !empty($_REQUEST['vote']) ? (array) $_REQUEST['vote'] : 0;
    $vote_opt_null = array(
        'title'      => '',
        'type'       => 'single',
        'time'       => current_time('Y-m-d H:i:s'), //创建时间
        'time_limit' => 0, //有效时间限制
        'options'    => array(),
    );
    $opt = wp_parse_args($opt, $vote_opt_null);

    if ($s) {
        //如果开启了
        //对内容进行处理，避免xss
        $new_options = array();
        foreach ($opt['options'] as $v) {
            $v = trim(strip_tags($v));
            if (in_array($v, $new_options)) {
                zib_send_json_error('投票选项的内容不能相同');
            }
            if (_new_strlen($v) > 1) {
                $new_options[] = esc_attr($v);
            }
        }
        $opt['options']    = $new_options;
        $opt['time_limit'] = (int) $opt['time_limit'];

        $opt['title'] = esc_attr(trim(strip_tags($opt['title'])));

        if (count($opt['options']) < 2) {
            //如果选项小于2
            zib_send_json_error('投票选项太少或选项内容字数太短');
        }

        if ($opt['title'] && _new_strlen($opt['title']) > 20) {
            zib_send_json_error('投票标题太长，最多20个字');
        }

        //保存开关
        update_post_meta($post_id, 'vote', true);
        update_post_meta($post_id, 'vote_option', $opt);
        if ($echo_success) {
            zib_send_json_success(array('msg' => '投票信息已保存', 'vote_option' => $opt, 'post_id' => $post_id));
        }
    } else {
        //保存开关
        update_post_meta($post_id, 'vote', false);
        if ($echo_success) {
            zib_send_json_success(array('msg' => '投票已关闭'));
        }
    }
}

//保存阅读权限
function zib_bbs_ajax_edit_allow_view($post_id = 0, $echo_success = true)
{
    if (!isset($_REQUEST['allow_view']) && !isset($_REQUEST['allow_view_roles'])) {
        return;
    }

    $post_id = $post_id ? $post_id : (!empty($_REQUEST['post_id']) ? $_REQUEST['post_id'] : 0);

    $allow_view       = !empty($_REQUEST['allow_view']) ? $_REQUEST['allow_view'] : '';
    $allow_view_roles = !empty($_REQUEST['allow_view_roles']) ? (array) $_REQUEST['allow_view_roles'] : array();
    $allow_view_roles = array_filter($allow_view_roles);

    if ('roles' == $allow_view) {
        if (!$allow_view_roles) {
            zib_send_json_error('请至少选择一项允许查看的用户类型');
        }
    }

    update_post_meta($post_id, 'allow_view', $allow_view);
    update_post_meta($post_id, 'allow_view_roles', $allow_view_roles);
    if ($echo_success) {
        zib_send_json_success(array('msg' => '阅读权限已保存', 'reload' => true, 'allow_view_roles' => $allow_view_roles, 'allow_view' => $allow_view, 'post_id' => $post_id));
    }
}
add_action('wp_ajax_edit_allow_view', 'zib_bbs_ajax_edit_allow_view');

//前台投票
function zib_bbs_ajax_submit_vote()
{
    $post_id = !empty($_REQUEST['id']) ? (int) $_REQUEST['id'] : '';
    $voted   = !empty($_REQUEST['voted']) ? (array) $_REQUEST['voted'] : '';

    if (!$voted) {
        zib_send_json_error('请选择投票选项');
    }
    $vote_ing = get_post_meta($post_id, 'vote_data', true); //已经投票内容
    $vote_ing = (is_array($vote_ing)) ? $vote_ing : array();
    $user_id  = get_current_user_id();

    foreach ($voted as $index) {
        $vote_ing[$index][] = $user_id;
    }
    $new = $vote_ing;

    //内容去重复
    /**
    $new = array();
    foreach ($vote_ing as $k => $v) {
    $new[$k] = $v;
    }
     */
    update_post_meta($post_id, 'vote_data', $new);
    zib_send_json_success(array('data' => zib_bbs_get_vote_data($post_id), 'vote_data' => $new));

}
add_action('wp_ajax_submit_vote', 'zib_bbs_ajax_submit_vote');

//版主申请
function zib_bbs_ajax_apply_moderator_modal()
{
    $plate_id = !empty($_REQUEST['plate_id']) ? (int) $_REQUEST['plate_id'] : 0;

    //已经是版主
    global $zib_bbs;
    if (zib_bbs_is_the_moderator($plate_id)) {
        zib_ajax_notice_modal('info', '您已是该' . $zib_bbs->plate_name . '的' . $zib_bbs->plate_moderator_name);
    }

    //已经有申请中的流程
    $processing = zib_bbs_get_apply_moderator_processing();
    if ($processing) {
        //已经有申请中的流程
        $moderator_name = $zib_bbs->plate_moderator_name;
        $header         = zib_get_modal_colorful_header('jb-yellow', zib_get_svg('plate-fill'), '申请成为' . $moderator_name);

        $plate_title = get_the_title($processing->meta['plate_id']);
        $con         = '<h5 class="c-red mb20">您的' . $moderator_name . '申请审核处理中，请耐心等待！</h5>';
        $con .= '<div class="mb10 muted-2-color">申请' . $zib_bbs->plate_name . '：' . $plate_title . '</div>';
        $con .= '<div class="mb10 muted-2-color">提交说明：' . $processing->meta['desc'] . '</div>';
        $con .= '<div class="mb20 muted-2-color">提交时间：' . $processing->meta['time'] . '</div>';
        $con .= '<div class="modal-buts but-average"><a type="button" data-dismiss="modal" class="but" href="javascript:;">取消</a></div>';

        echo $header . $con;
        exit;
    }

    echo zib_bbs_get_apply_moderator_modal($plate_id);
    exit;
}
add_action('wp_ajax_apply_moderator_modal', 'zib_bbs_ajax_apply_moderator_modal');

//手动设置评论为神评论
function zib_bbs_ajax_comment_set_hot()
{

    $id     = !empty($_REQUEST['id']) ? $_REQUEST['id'] : 0;
    $is_hot = get_comment_meta($id, 'is_hot', true);
    if ($is_hot) {
        update_comment_meta($id, 'is_hot', 0);
        zib_send_json_success(['msg' => '已取消此评论的神评称号', 'reload' => true]);
    } else {
        update_comment_meta($id, 'is_hot', 1);
        zib_send_json_success(['msg' => '已将此评论设为神评', 'reload' => true]);
    }

}
add_action('wp_ajax_comment_set_hot', 'zib_bbs_ajax_comment_set_hot');
