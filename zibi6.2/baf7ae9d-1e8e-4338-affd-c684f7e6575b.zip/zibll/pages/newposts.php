<?php

/**
 * Template name: Zibll-写文章、投稿页面
 * Description:   用户前台发布文章的页面模板
 */

get_header();
$cuid = get_current_user_id();

//不显示悬浮按钮
remove_action('wp_footer', 'zib_float_right');

if (!$cuid) {
    $btn_txet = '审核';
} else {
    $btn_txet = '发布';
}

if (!_pz('post_article_s') || zib_is_close_sign()) {
    get_template_part('template/content-404');
    get_footer();
    exit();
}

//编辑器按钮
if (zib_current_user_can('new_post_upload_img')) {
    add_filter('tinymce_upload_img', '__return_true');
}
//编辑器按钮
if (zib_current_user_can('new_post_upload_video')) {
    add_filter('tinymce_upload_video', '__return_true');
}
//编辑器按钮
if (zib_current_user_can('new_post_hide')) {
    add_filter('tinymce_hide', '__return_true');
}

?>
<main role="main" class="container">
    <form>
        <?php
        $draft_id = get_user_meta($cuid, 'posts_draft', true);
        if (_pz('post_article_edit_s')) {
            $draft_id = !empty($_REQUEST['edit']) ? $_REQUEST['edit'] : $draft_id;
        }
        $post_title   = '';
        $post_content = '';
        $post_cat     = '';
        $post_tags    = '';
        $post_tag     = '';
        $post_uptime  = '';
        $view_btn     = '';
        if ($draft_id && $cuid) {
            $parsed_args = array(
                'post__in'    => array($draft_id),
                'post_status' => 'draft',
                'author'      => $cuid,
            );

            $get_posts = new WP_Query;
            $draft     = $get_posts->query($parsed_args);

            if (!empty($draft[0])) {
                $post_title   = $draft[0]->post_title;
                $post_content = $draft[0]->post_content;
                $post_uptime  = '<span class="badg">最后保存：' . $draft[0]->post_modified . '</span>';
                $post_cat     = get_the_category($draft_id)[0]->term_id;
                $post_tags    = get_the_tags($draft_id);

                if ($post_tags) {
                    $post_tags = array_column((array) $post_tags, 'name');
                    $post_tags = implode(', ', $post_tags);
                }
                $view_btn = (is_user_logged_in() && current_user_can('edit_post', $draft_id)) ? '<a target="_blank" href="' . get_permalink($draft_id) . '" class="but c-blue mr10"><i class="fa fa-file-text-o" aria-hidden="true"></i> 预览文章</a>' : '';
            } else {
                $draft_id = false;
                update_user_meta($cuid, 'posts_draft', false);
            }
        }
        ?>
        <div class="content-wrap newposts-wrap">
            <div class="content-layout">
                <div class="main-bg theme-box radius8 box-body main-shadow">
                    <div class="relative mb6 newposts-title">
                        <textarea type="text" class="line-form-input input-lg new-title" name="post_title" tabindex="1" rows="1" autoHeight="true" maxHeight="83" placeholder="请输入文章标题"><?php echo esc_attr($post_title); ?></textarea>
                        <i class="line-form-line"></i>
                    </div>
                    <?php
                    //  echo '<pre>'.json_encode($draft).'</pre>';
                    $content   = $post_content;
                    $editor_id = 'post_content';
                    $settings  = array(
                        'textarea_rows'  => 20,
                        'editor_height'  => (wp_is_mobile() ? 360 : 460),
                        'media_buttons'  => false,
                        'default_editor' => 'tinymce',
                        'quicktags'      => false,
                        'editor_css'     => '<link rel="stylesheet" href="' . ZIB_TEMPLATE_DIRECTORY_URI . '/css/new-posts.min.css" type="text/css">',
                        'teeny'          => false,
                    );

                    if (!zib_current_user_can('new_post_add')) {
                        echo '<div class="flex jc" style="min-height:50vh;">';
                        echo zib_get_nocan_info($cuid, 'new_post_add', '无法发布');
                        echo '</div>';
                    } else {
                        wp_editor($content, $editor_id, $settings);
                    }

                    ?>
                    <?php echo '<div class="em09 mt10"><span class="view-btn">' . $view_btn . '</span><span class="modified-time">' . $post_uptime . '</span></div>'; ?>
                </div>
            </div>
        </div>

        <div class="sidebar show-sidebar">

            <?php if (!$cuid) {
            ?>
                <div class="main-bg theme-box radius8 main-shadow relative">
                    <div class="box-header">
                        <div class="title-theme">用户信息</div>
                    </div>
                    <div class="box-body">
                        <p class="muted-3-color em09">请输入昵称</p>
                        <div class="mb20">
                            <input class="form-control" name="user_name" placeholder="请输入昵称">
                        </div>
                        <p class="muted-3-color em09">请输入您的联系方式</p>
                        <input class="form-control" name="contact_details" placeholder="输入联系方式">
                    </div>
                </div>
            <?php } ?>
            <div class="theme-box">
                <div class="main-bg theme-box radius8 main-shadow relative">
                    <div class="box-header">
                        <div class="title-theme">文章分类</div>
                    </div>
                    <div class="box-body">
                        <p class="muted-3-color em09">请选择文章分类</p>
                        <div class="form-select">
                            <select class="form-control" name="category" tabindex="5">
                                <?php
                                $cat_ids = _pz('post_article_cat', array());

                                $cats = get_categories(array(
                                    'orderby'    => 'include',
                                    'include'    => $cat_ids,
                                    'hide_empty' => false,
                                ));

                                if ($cats) {
                                    foreach ($cats as $cat) {
                                        echo '<option value="' . $cat->term_id . '" ' . selected($cat->term_id, $post_cat, false) . '>' . $cat->name . '</option>';
                                    }
                                } else {
                                    echo '<option value="1" selected="selected">' . get_category(1)->name . '</option>';
                                }
                                ?>
                            </select>
                        </div>

                    </div>
                    <div class="box-header">
                        <div class="title-theme">文章标签</div>
                    </div>
                    <div class="box-body">
                        <p class="muted-3-color em09">填写文章的标签，每个标签用逗号隔开</p>
                        <textarea class="form-control" rows="3" name="tags" placeholder="输入文章标签" tabindex="6"><?php echo $post_tags; ?></textarea>
                    </div>
                </div>
            </div>
            <div class="zib-widget">
                <div class="text-center">
                    <p class="separator muted-3-color theme-box">Are you ready</p>
                    <?php
                    if ($draft_id) {
                        echo '<input type="hidden" name="posts_id" value="' . $draft_id . '">';
                    }
                    $btns = '';

                    if (!zib_current_user_can('new_post_add')) {
                        echo '<p class="em09 muted-3-color theme-box">暂时无法发布文章</p>';
                    } else {
                        if (is_user_logged_in()) {
                            echo '<p class="em09 muted-3-color theme-box">如果您的文章还未完全写作完成，请先保存草稿，文章提交' . $btn_txet . '之后不可再修改！</p>';
                            $btns .= '<botton type="button" action="posts_draft" name="submit" class="but jb-green new-posts-submit padding-lg"><i class="fa fa-fw fa-dot-circle-o"></i>保存草稿</botton>';
                        } else {
                            echo '<p class="em09 muted-3-color theme-box">您当前未登录，不能保存草稿，文章提交' . $btn_txet . '之后不可再修改！</p>';
                        }
                        $btns .= '<botton type="button" action="posts_save" name="submit" class="ml10 but jb-blue new-posts-submit padding-lg"><i class="fa fa-fw fa-check-square-o"></i>提交' . $btn_txet . '</botton>';
                    }

                    echo $btns ? '<div class="but-average  ">' . $btns . '</div>' : '';
                    ?>
                </div>
            </div>
        </div>
    </form>
</main>
<?php get_footer();
